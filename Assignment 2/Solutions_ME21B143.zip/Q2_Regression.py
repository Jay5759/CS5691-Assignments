# %%
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
from tabulate import tabulate

# %%
data_train_raw = pd.read_csv("A2Q2Data_train.csv")
data_test = pd.read_csv("A2Q2Data_test.csv")
data_train = np.array(data_train_raw)
data_test = np.array(data_test)
print(tabulate(data_test))
data_test.shape

# %% [markdown]
# ### Calculating X and y from data

# %%
n = 10000 # Data points in train dataset
n_test = 500 # Data points in test dataset
d = 100 # No. of features
y = np.zeros((n)) # Labels for datapoints

X = np.zeros((d,n))
for i in range(n):
    for j in range(d):
        X[j][i] = data_train[i][j]

for i in range(n):
    y[i] = data_train[i][100]

# %% [markdown]
# ## i. Computing least square solution

# %%
# Step 1:- Transpose the Feature matrix X
X_trans = X.T

# Step 2:- Compute XXt
XXt = np.zeros((d,d))
for i in range(d):
    for j in range(d):
        XXt[i][j] = np.dot(X[i],X_trans[:,j])

# Step 3:- Compute the pseudo inverse of XXt
XXt_inv = np.linalg.pinv(XXt) 

# Step 4:- Compute (XXt)^-1*X
mat = np.zeros((d,n))
for i in range(d):
    for j in range(n):
        mat[i][j] = np.dot(XXt_inv[i],X[:,j])

# Step 5:- Mutliply (XXt)^-1*X with y and get W_ml
W_ml = np.zeros((d))
for i in range(d):
    W_ml[i] = np.dot(mat[i],y)
print(W_ml)

# %% [markdown]
# ## ii. Gradient Descent Algorithm

# %%
def grad_func(X,XXt,y,w):
    temp1 = np.zeros((d))
    for i in range(d):
        temp1[i] = np.dot(XXt[i],w)
    temp2 = np.zeros((d))
    for i in range(d):
       temp2[i] = np.dot(X[i],y)
    return 2*(temp1 - temp2)

T = 1000 # No. of rounds
learning_rate = 0.000001

w_grad = np.zeros((T,d))
for i in range(T-1):
    temp1 = grad_func(X,XXt,y,w_grad[i])
    inta = learning_rate / (i+1) # Step size
    w_grad[i + 1] = w_grad[i] - inta * temp1

norms_grad = np.zeros((T-1))
for i in range(1,T):
    norms_grad[i-1] = np.linalg.norm(w_grad[i]-W_ml)**2

plt.plot(norms_grad)
plt.xlabel('Iteration (t)')
plt.ylabel('||w_t - w_ML||^2')
plt.title('Error as a function of Iteration')
plt.show()

# %% [markdown]
# ## iii. Stochastic Gradient Descent Algorithm

# %%
T_SGD = 1000 # No.of rounds
learning_rate_SGD = 0.000001
Q = 100 # Batch size

def del_func_SGD(data_SGD,w):
    X_SGD = np.zeros((d,Q))
    for i in range(Q):
        for j in range(d):
            X_SGD[j][i] = data_SGD[i][j]
    
    y_SGD = np.zeros((Q)) # Labels for datapoints
    for i in range(Q):
        y_SGD[i] = data_SGD[i][100]

    X_trans_SGD = X_SGD.T
    XXt_SGD = np.zeros((d,d))
    XXt_SGD = np.dot(X_SGD,X_trans_SGD)
        
    temp1 = np.zeros((d))
    temp1 = np.dot(XXt_SGD,w)

    temp2 = np.zeros((d))
    temp2 = np.dot(X_SGD,y_SGD)
    return 2*(temp1 - temp2)

W_SGD = np.zeros((T_SGD,d))
for i in range(T_SGD-1):
    data_SGD = data_train_raw.sample(frac=0.01)
    data_SGD = np.array(data_SGD)
    temp1 = del_func_SGD(data_SGD,W_SGD[i])
    inta = learning_rate_SGD / (i + 1) # Step size
    W_SGD[i + 1] = W_SGD[i] - inta * temp1

norms_SGD = np.zeros((T-1))
for i in range(1,T):
    norms_SGD[i-1] = np.linalg.norm(W_SGD[i]-W_ml)**2

plt.plot(norms_SGD)
plt.xlabel('Iteration (t)')
plt.ylabel('||w_t - w_ML||^2')
plt.title('Error as a function of Iteration')
plt.show()

# %% [markdown]
# ## iv. Ridge Regression

# %%
def get_w(lamda,X_ridge,y_ridge):
    # Step 1:- Transpose the feature matrix
    X_ridge_trans = X_ridge.T
    
    # Step 2:- Compute XXt
    XXt_ridge = np.zeros((d,d))
    for i in range(d):
        for j in range(d):
            XXt_ridge[i][j] = np.dot(X_ridge[i],X_ridge_trans[:,j])

    # Step 3:- Compute XXt + λI
    for i in range(d):
        XXt_ridge[i][i] += lamda
    
    # Step 4:- Compute the pseudo inverse of XXt
    XXt_ridge_inv = np.linalg.pinv(XXt_ridge) 
    
    # Step 5:- Compute Xy
    mat = np.zeros((d,len(X_ridge[0])))
    for i in range(d):
        for j in range(len(X_ridge[0])):
            mat[i][j] = np.dot(XXt_ridge_inv[i],X_ridge[:,j])
    
    W_ridge = np.zeros((d))
    for i in range(d):
        W_ridge[i] = np.dot(mat[i],y_ridge)

    return W_ridge

def divide_dataset(X,y):
    # Shuffle the indices of the dataset
    indices = np.arange(n)
    np.random.shuffle(indices)
    
    # Calculate the split indices
    split_index = int(0.8 * n)
    
    # Split the indices into training and validation
    train_indices = indices[:split_index]
    val_indices = indices[split_index:]
    
    # Create training and validation datasets
    X_train, y_train = X[train_indices], y[train_indices]
    X_val, y_val = X[val_indices], y[val_indices]

    return X_train,y_train,X_val,y_val

# %%
X_train,y_train,X_val,y_val = divide_dataset(X.T,y)
X_train = X_train.T
X_val = X_val.T

samples = 6
lambda_values = np.array((0.001,0.01,0.1,1,10,100))

W_ridge_train = np.zeros((samples,d))
error_val = np.zeros((samples))
for i in range(samples):
    W_ridge_train[i] = get_w(lambda_values[i],X_train,y_train)
    error_val[i] = np.linalg.norm(np.dot((X_val.T),W_ridge_train[i]) - y_val)**2 + lambda_values[i]*np.linalg.norm(W_ridge_train[i])**2

plt.plot(lambda_values,error_val)
plt.xlabel('λ')
plt.ylabel('Validation error')
plt.title('Error as a function of λ')
plt.xscale('log')
plt.grid(True)
plt.show()

# %% [markdown]
# ### Computing Test error for W_ridge and W_ml

# %%
lamda = lambda_values[np.argmin(error_val)]
W_ridge = get_w(lamda,X_train,y_train)
print(W_ridge)

X_test = np.zeros((d,n_test))
for i in range(n_test):
    for j in range(d):
        X_test[j][i] = data_test[i][j]

y_test = np.zeros((n_test)) # Labels for datapoints
for i in range(n_test):
    y[i] = data_test[i][100]

error_test_ridge = 0.0
error_test_ml = 0.0
error_test_ml = np.linalg.norm(np.dot((X_test.T),W_ml) - y_test)**2 + lamda*np.linalg.norm(W_ml)**2
error_test_ridge = np.linalg.norm(np.dot((X_test.T),W_ridge) - y_test)**2 + lamda*np.linalg.norm(W_ridge)**2

print('error in test dataset from W_ml is ',error_test_ml)
print('error in test dataset from W_ridge is ',error_test_ridge)


