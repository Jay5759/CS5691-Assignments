# %%
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
import random
import math

# %%
data = pd.read_csv("A2Q1.csv")
data = np.array(data)
n = len(data) # No. of data points
d = 50 # dimensions
k = 4 # No. of Mixtures
epsilon = 1e-10  # Small epsilon value

# %% [markdown]
# ## i. EM Algorithm with Bernoulli Mixture

# %%
def init_bern(u,p):
    sum = 0.0
    for i in range(k):
        for j in range(d):
            u[i][j] = random.random()
        p[i] = random.random()
        sum += p[i]
    for i in range(k):
        p[i] /= sum

def f_bern(x,p):
    sum = 0.0
    for i in range(d):
        sum += (p[i]**x[i])*((1-p[i])**(1-x[i]))
    return sum

def Log_Likelihood_bern(u,p):
    ans = 0.0
    for i in range(n):
        sum = 0.0
        for j in range(k):
            sum += p[j]*f_bern(data[i],u[j])
        ans += np.log(sum)
    return ans

# %%
u_bern = np.zeros((k,d))
p_bern = np.zeros((k))
log_likelihood_bern = np.zeros((100000))
tolerance_bern = 0.01

for l in range(100):
    count = 0
    log_likelihood_temp = np.zeros((100000))
    init_bern(u_bern,p_bern)
    while True:
        z_bern = np.zeros((n,k))
        
        # Expectation Step
        for i in range(n):
            sum = 0.0
            for j in range(k):
                sum += p_bern[j]*f_bern(data[i],u_bern[j])
            for j in range(k):
                z_bern[i][j] = (p_bern[j]*f_bern(data[i],u_bern[j]))/sum

        # Maximization Step
        for i in range(k):
            p_bern[i] = 0.0
            for j in range(n):
                p_bern[i] += z_bern[j][i]
            p_bern[i] /= n

        for i in range(k):
            sum = 0.0
            u_bern[i] = 0.0
            for j in range(n):
                sum += z_bern[j][i]
                u_bern[i] += z_bern[j][i]*data[j]
            if sum != 0.0: u_bern[i] /= sum

        log_likelihood_temp[count] = Log_Likelihood_bern(u_bern,p_bern)
        if count != 0: log_likelihood_bern[count] = log_likelihood_bern[count-1] + log_likelihood_temp[count]
        else: log_likelihood_bern[count] = log_likelihood_temp[count]

        # Convergence Criteria 
        if count != 0:
            error_bern = (log_likelihood_bern[count] - log_likelihood_bern[count-1])/log_likelihood_bern[count]
            if error_bern < tolerance_bern:
                break
            print(error_bern)
        count += 1

log_likelihood_bern /= 100

# print(count)
log_likelihood_bern = log_likelihood_bern[log_likelihood_bern != 0]
# print(log_likelihood_bern)

plt.plot(log_likelihood_bern[:99])
plt.xlabel('Iteration (t)')
plt.ylabel('Log-Likelihood')
plt.title('log-likelihood as a function of Iteration')
plt.show()

# %% [markdown]
# ## ii. EM Algorithm with Gaussian Mixture

# %%
def init_gauss_random(data, k):
    # Initialize means randomly
    u_gauss = np.random.uniform(low=np.min(data), high=np.max(data), size=(k, data.shape[1]))

    # Initialize covariance matrices as identity matrices
    sig = np.tile(np.eye(data.shape[1])[np.newaxis], (k, 1, 1))

    sum = 0.0
    p_gauss = np.zeros((k))
    for i in range(k):
        p_gauss[i] = random.random()
        sum += p_gauss[i]
    for i in range(k):
        p_gauss[i] /= sum

    return u_gauss, sig, p_gauss

def f_gauss(x,u,sig):
    sig_inv = np.linalg.pinv(sig)  # Compute the pseudoinverse of the covariance matrix
    exponent = -0.5 * (x - u).T @ sig_inv @ (x - u)
    det_sig = np.linalg.det(sig)
    if det_sig <= 0:
        return 0  # Avoid negative or zero determinant
    else:
        denominator = np.sqrt((2 * np.pi) ** d * det_sig)
        return np.exp(exponent) / denominator

def Log_Likelihood_gauss(u,sig,p):
    ans = 0.0
    for i in range(n):
        temp = 0.0
        for j in range(k):
            gauss_val = f_gauss(data[i], u[j], sig[j])
            if gauss_val == 0:
               temp += 0  # Avoid division by zero
            else:
               temp += p[j] / max(gauss_val, 1e-6)
        if temp == 0:
            continue
        ans += np.log(temp)
    return (ans)

# %%
u_gauss = np.zeros((k,d))
sig = np.zeros((k,d,d))
p_gauss = np.zeros((k))
log_likelihood_gauss = np.zeros((1000))
tolerance_gauss = 0.1
    
for l in range(100):
    count_gauss = 0
    log_likelihood_temp = np.zeros((1000))
    u_gauss, sig, p_gauss = init_gauss_random(data, k)
    while True:
        lamda = np.zeros((n,k))
    
        # Expectation step
        for i in range(n):
            sum_lamda = 0.0
            for j in range(k):
                lamda[i][j] = f_gauss(data[i], u_gauss[j], sig[j]) * p_gauss[j]
                sum_lamda += lamda[i][j]
            if sum_lamda == 0:
                lamda[i] = [1/k] * k
            else:
                lamda[i] /= sum_lamda
        
        #Maximization step
        for i in range(k):
            # Update mixing coefficients
            p_gauss[i] = np.sum(lamda[:, i]) / n
            
            # Update means
            if np.sum(lamda[:, i]) == 0:
                # If no points assigned to this cluster, randomly initialize the mean
                u_gauss[i] = np.random.rand(d)
            else:
                # Otherwise, compute the weighted mean of points assigned to this cluster
                u_gauss[i] = np.sum(data * lamda[:, i][:, None], axis=0) / np.sum(lamda[:, i])
            
            # Update covariance matrices
            sum_sig = np.zeros((d, d))
            for j in range(n):
                sum_sig += lamda[j][i] * np.outer(data[j] - u_gauss[i], data[j] - u_gauss[i])
            if np.sum(lamda[:, i]) == 0:
                # If no points assigned to this cluster, set covariance matrix to identity matrix
                sig[i] = np.eye(d)
            else:
                # Otherwise, compute the weighted covariance matrix
                sig[i] = np.linalg.pinv(sum_sig / np.sum(lamda[:, i]))
    
        log_likelihood_temp[count_gauss] = Log_Likelihood_gauss(u_gauss,sig,p_gauss)
        if count_gauss != 0: log_likelihood_gauss[count_gauss] = log_likelihood_gauss[count_gauss-1] + log_likelihood_temp[count_gauss]
        else: log_likelihood_gauss[count_gauss] = log_likelihood_temp[count_gauss]
    
        # Convergence Criteria 
        if count_gauss != 0:
            error_gauss = (log_likelihood_gauss[count_gauss] - log_likelihood_gauss[count_gauss-1])/max(log_likelihood_gauss[count_gauss], 1e-6)
            if error_gauss < tolerance_gauss:
                break
            # print(error_gauss)
        count_gauss += 1

    print(l)

log_likelihood_gauss /= 100

# %%
print(count_gauss)
log_likelihood_gauss = log_likelihood_gauss[log_likelihood_gauss != 0]
print(log_likelihood_gauss)

plt.plot(log_likelihood_gauss,marker = 'o')
plt.xlabel('Iteration (t)')
plt.ylabel('Log-Likelihood')
plt.title('log-likelihood as a function of Iteration')
plt.show()

# %%
# Plotting both log-likelihood curves
plt.plot(log_likelihood_bern, label='Bernoulli Mixture')
plt.plot(log_likelihood_gauss, label='Gaussian Mixture')

# Adding labels and legend
plt.xlabel('Iterations')
plt.ylabel('Log-Likelihood')
plt.title('Log-Likelihood Comparison')
plt.legend()

# Display the plot
plt.show()

# %% [markdown]
# ## iii. K-Means Algorithm with K = 4

# %%
def init(z):
    for i in range(n):
        z[i] = random.randint(0,3)
    return z

def Error(data,z,mean):
    ans = 0
    for i in range(n):
        ans += np.linalg.norm(data[i]-mean[int(z[i])])**2
    return ans

# %%
def K_Means(data,error,k):
   iteration = 0 
   z = np.zeros((n))
   init(z)
   while True:
       mean = np.zeros((k,d))
       cnt = np.zeros((k))
       for i in range(n):
           x = int(z[i])
           mean[x] += data[i]
           cnt[x] += 1
       for i in range(k):
           if cnt[i]==0: cnt[i]=1
           mean[i] = mean[i]/cnt[i]
       check = 0
       for i in range(n):
           temp1 = z[i]
           x = np.linalg.norm(data[i] - mean[int(z[i])]) ** 2
           for j in range(k):
               if np.linalg.norm(data[i] - mean[j]) ** 2 < x: 
                   z[i] = j
           if temp1==z[i]:
               check += 1
       if check==n:
           break
       error[iteration] = Error(data,z,mean)
       iteration += 1
   return z

error_K = np.zeros((n))
z = K_Means(data,error_K,k)
error_K = error_K[error_K != 0.0]
print(error_K)
plt.plot(error_K,marker = 'o')
plt.xlabel("iterations")
plt.ylabel("Objective Function")

# %% [markdown]
# ## iv. Hard clustering for comparison

# %%
z_gaussian = np.zeros((n))
for i in range(n):
    z_gaussian[i] = np.argmax(lamda[i])
mean_gaussian = np.zeros((k, d))
counts_gaussian = np.zeros(k, dtype=int)
for i in range(n):
    mean_gaussian[int(z_gaussian[i])] += data[i]
    counts_gaussian[int(z_gaussian[i])] += 1
for j in range(k):
    if counts_gaussian[j] != 0: mean_gaussian[j] /= counts_gaussian[j]

z_bernoulli = np.zeros((n))
for i in range(n):
    z_bernoulli[i] = np.argmax(z_bern[i])
mean_bernoulli = np.zeros((k, d))
counts_bernoulli = np.zeros(k, dtype=int)
for i in range(n):
    mean_bernoulli[int(z_bernoulli[i])] += data[i]
    counts_bernoulli[int(z_bernoulli[i])] += 1
for j in range(k):
    if counts_bernoulli[j] != 0: mean_bernoulli[j] /= counts_bernoulli[j]

# %%
obj_gaussian = 0
for i in range(n):
    obj_gaussian += np.linalg.norm(data[i]-mean_gaussian[int(z_gaussian[i])])**2
print('Objective value for GMM is ',obj_gaussian)

obj_bernoulli = 0
for i in range(n):
    obj_bernoulli += np.linalg.norm(data[i]-mean_bernoulli[int(z_bernoulli[i])])**2
print('Objective value for BMM is ',obj_bernoulli)

print('objective value for K-Means is ', error_K[error_K.size-1])


